#Programa receber valor e soma
'''
Esse programa solicita a entrada de dois numeros
soma e mostra resultado
 
'''
num1=int(input("Digite primeiro valor: "))
num2=int(input('Digite o segundo numero: '))
print('Soma: ',num1+num2)
print(num1-num2)
print(num1*num2)
print(num1/num2)
print(f'A soma de {num1} com {num2}, e  ',num1+num2)