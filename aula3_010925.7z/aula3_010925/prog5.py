
#utilizando estrura de dados
#Lista
nome_aluno = ''
nome_cliente =[]
print(type(nome_aluno))
print(type(nome_cliente))

lista_compras = ['uva','laranja','maçã']
for n in lista_compras:
    print(n)

print(lista_compras[0])   #exibe item posicao 0
print(lista_compras[1])   #exibe item posicao 0
print(lista_compras[-1])  #exibe última posicao
 
del lista_compras[2]      # apaga item posicao 2
lista_compras.insert(1,'Abacaxi')
#insere dados na posicao 1
print(lista_compras)
lista_compras.append('goiaba')
#insere goiaba no final da lista
print(lista_compras)
lista_compras.remove('laranja')
#remove item da lista
print(lista_compras)



