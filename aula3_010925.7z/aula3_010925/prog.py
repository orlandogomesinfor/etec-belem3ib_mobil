print("Aula")

nome="José Carlos"  # Variável do tipo String
idade=20            #   "          "   Inteiro
salario=2500.80     #   "           "  Float
estuda=True         #   "           "  Boolean

print('Nome ',nome)
print(f'nome {nome}')
print('Aluno: ',nome,' Idade: ',idade)
print(f"Aluno: {nome } idade: {idade}")

print(type(idade))