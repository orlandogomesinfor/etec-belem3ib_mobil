#Estrutura de dados em Python
#Lista: armazena um conjunto de dados de tipos diferente, oferece
# um conjunto de métodos par z