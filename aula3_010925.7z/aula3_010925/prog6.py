#uso do while
n=3
x=0
while x<n:
   print("ETEC-Belém")
   x+=1

#uso do for
for n in range(3):
   print("ETEC - Curso Mobil")
