idade=[]
nome=[]
while True:
    nome.append(input('Digite o nome: '))
    idade.append(int(input('Digite a idade: ')))
    opcao=input('Digite s para sair: ')
    if opcao=='s':
        break
print(nome)